'use client';

export default function ReservationManager() {
  return (
    <div className="p-6">
      <div className="card p-8 text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Reservation Manager</h2>
        <p className="text-gray-600">Coming soon - Full reservation management system</p>
      </div>
    </div>
  );
}
