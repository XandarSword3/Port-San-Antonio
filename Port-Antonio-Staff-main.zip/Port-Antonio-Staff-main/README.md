# Port San Antonio - Staff Portal 🏨

Professional staff management system for Port San Antonio Resort & Restaurant.

## 🚀 Features

### Authentication & Role Management
- **Role-based access control**: Worker, Admin, Owner permissions
- **Secure authentication** with Supabase
- **Session management** with automatic logout

### Staff Management Tools
- **Menu Management**: Add, edit, delete menu items with categories
- **Order Management**: Real-time order tracking and updates
- **Kitchen Display**: Streamlined kitchen workflow interface
- **Reservations**: Complete booking management system
- **Events Management**: Special events and promotions
- **Analytics Dashboard**: Revenue, orders, and performance metrics
- **Staff Administration**: User roles and permissions management

### Technical Features
- **Real-time updates** with Supabase subscriptions
- **Responsive design** optimized for tablets and desktops
- **Modern UI/UX** with Tailwind CSS
- **TypeScript** for type safety
- **Next.js 13+** with App Router

## 🛠️ Tech Stack

- **Frontend**: Next.js 13+, React, TypeScript
- **Styling**: Tailwind CSS, Lucide React icons
- **Backend**: Supabase (PostgreSQL, Auth, Real-time)
- **Authentication**: Supabase Auth with RLS
- **Deployment**: Vercel (recommended)

## 📋 Prerequisites

- Node.js 18+ and npm/yarn
- Supabase account and project
- Git

## 🚀 Quick Start

### 1. Clone & Install
```bash
git clone https://github.com/XandarSword3/Port-Antonio-Staff.git
cd Port-Antonio-Staff
npm install
```

### 2. Environment Setup
```bash
cp .env.local.example .env.local
```

Configure your `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 3. Database Setup
Run the SQL schema in your Supabase dashboard:
```bash
# Execute the contents of supabase/schema.sql in your Supabase SQL editor
```

### 4. Development
```bash
npm run dev
```
Open [http://localhost:3002](http://localhost:3002)

## 📊 Default Users

After running the schema, you'll have these default accounts:

### Owner Account
- **Email**: `owner@portsanantonio.com`
- **Password**: `owner123`
- **Access**: Full system access

### Admin Account
- **Email**: `admin@portsanantonio.com`
- **Password**: `admin123`
- **Access**: Menu, orders, reservations, events

### Worker Account
- **Email**: `worker@portsanantonio.com`
- **Password**: `worker123`
- **Access**: Kitchen display, order updates

## 🏗️ Project Structure

```
src/
├── app/                 # Next.js app router
│   ├── layout.tsx      # Root layout
│   ├── page.tsx        # Dashboard page
│   └── globals.css     # Global styles
├── components/         # React components
│   ├── Dashboard.tsx   # Main dashboard
│   ├── MenuManager.tsx # Menu management
│   ├── OrderManager.tsx# Order tracking
│   └── ...
├── contexts/          # React contexts
│   └── AuthContext.tsx# Authentication
├── lib/              # Utilities
│   ├── supabase.ts   # Supabase client
│   └── toast.tsx     # Toast notifications
└── types/           # TypeScript types
    └── index.ts     # Shared types
```

## 🔐 Authentication Flow

1. **Login**: Users authenticate with email/password
2. **Role Check**: System verifies user role from database
3. **Dashboard**: Role-appropriate interface loads
4. **Permissions**: Features restricted by role level

## 📱 User Roles & Permissions

| Feature | Worker | Admin | Owner |
|---------|--------|-------|-------|
| Kitchen Display | ✅ | ✅ | ✅ |
| Order Updates | ✅ | ✅ | ✅ |
| Menu Management | ❌ | ✅ | ✅ |
| Reservations | ❌ | ✅ | ✅ |
| Events | ❌ | ✅ | ✅ |
| Analytics | ❌ | ✅ | ✅ |
| Staff Management | ❌ | ❌ | ✅ |

## 🚀 Deployment

### Vercel (Recommended)
1. Connect your GitHub repository to Vercel
2. Set environment variables in Vercel dashboard
3. Deploy automatically on push to main branch

### Manual Deployment
```bash
npm run build
npm start
```

## 🔧 Configuration

### Supabase Setup
1. Create a new Supabase project
2. Run the SQL schema from `supabase/schema.sql`
3. Configure Row Level Security (RLS) policies
4. Add your project credentials to `.env.local`

### Environment Variables
```env
NEXT_PUBLIC_SUPABASE_URL=          # Your Supabase project URL
NEXT_PUBLIC_SUPABASE_ANON_KEY=     # Your Supabase anon key
```

## 📈 Analytics Features

- **Revenue Tracking**: Daily, weekly, monthly revenue
- **Order Analytics**: Order volume and trends
- **Menu Performance**: Most popular items
- **Staff Performance**: Order completion times
- **Customer Insights**: Reservation patterns

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- Create an issue in this repository
- Contact the development team

## 🔄 Updates & Maintenance

- Regular security updates
- Feature enhancements based on staff feedback
- Performance optimizations
- Bug fixes and improvements

---

**Port San Antonio Staff Portal** - Streamlining resort operations with modern technology.
#   D e p l o y m e n t   t r i g g e r   -   0 9 / 1 0 / 2 0 2 5   1 0 : 4 9 : 5 2  
 D a t a b a s e   c o n n e c t e d   0 9 / 1 0 / 2 0 2 5   1 2 : 2 1 : 1 9  
 